# INM420 Git Assignment

Seneca INM420 Git Assignment

## Installation

Clone the repo to your local machine.

## Assignment
- Add your GitHub username to this Excel sheet: https://seneca-my.sharepoint.com/:x:/g/personal/sachin_devdhar_senecapolytechnic_ca/Ecs0HzLFM6VIoUKMbqu1KnwB1CflhLfB9kX0tDoy4NM3og?e=Q066Tw

## Contributing
Add your GitHub account name in the Excel sheet provided above to be added as a contributor. Edit the stylesheet to style your name.

## License
[MIT](https://choosealicense.com/licenses/mit/)
